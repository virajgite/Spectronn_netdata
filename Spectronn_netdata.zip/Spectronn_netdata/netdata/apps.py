from django.apps import AppConfig


class NetdataConfig(AppConfig):
    name = 'netdata'
